# Kato Tu Tiên — Gói cập nhật Moderation thủ công v3.8.0

Gói này được viết dựa trên repository `itsk4to/KTT102026`, mã nguồn nằm trong
`kato-tutien/`, phiên bản cơ sở `3.7.4` và database schema `16`.

## Chức năng có trong bản cập nhật

Các lệnh nằm trong nhóm Slash Command `/mod`:

| Lệnh | Tác dụng |
|---|---|
| `/mod ban` / `/mod unban` | Ban hoặc gỡ ban |
| `/mod kick` | Kick thành viên |
| `/mod timeout` / `/mod untimeout` | Timeout hoặc gỡ timeout |
| `/mod warn` / `/mod warnings` | Ghi và xem cảnh cáo |
| `/mod purge` | Xóa tối đa 100 tin nhắn trong kênh |
| `/mod slowmode` | Chỉnh slowmode từ 0 đến 21600 giây |
| `/mod lock` / `/mod unlock` | Khóa kênh và khôi phục trạng thái gửi tin trước khi khóa |
| `/mod logs` / `/mod case` | Tra cứu lịch sử xử lý |

Đây là hệ thống quản trị thủ công. Không có tự động quét link mời, tự động
xóa tin nhắn, tự động timeout hay tự động ban.

## Cấu trúc tích hợp

- `ui/commands/moderation.py`: nhóm Slash Commands trên `CommandTree` hiện có.
- `game/moderation/service.py`: lớp dịch vụ quản trị.
- `game/moderation/repository.py`: lưu và truy vấn moderation cases.
- `moderation_cases`: bảng dữ liệu riêng, không dùng chung `admin_audit` của game.
- Migration schema `16 → 17`; không reset dữ liệu người chơi.

## Cách áp dụng

1. Sao lưu database SQLite đang chạy.
2. Giải nén ZIP vào thư mục gốc repository (thư mục có `kato-tutien/`) để chép
   các file Python mới vào đúng vị trí.
3. Mở terminal tại thư mục gốc repository và chạy:

   ```bash
   python apply_update.py
   ```

4. Xem lại thay đổi bằng `git diff` trước khi commit/push.
5. Deploy bản cập nhật. Khi bot khởi động, migration runner sẽ thêm bảng
   `moderation_cases` và nâng schema lên `17`.

Script áp dụng có kiểm tra phiên bản nguồn, có thể chạy lại mà không chèn trùng
các thay đổi. Nếu repo của bạn đã khác `3.7.4`, script sẽ dừng khi không tìm
thấy điểm neo phù hợp; lúc đó cần đối chiếu thủ công, không ép ghi đè.

## Cấu hình biến môi trường

Thêm vào cấu hình môi trường của host (không đưa token/mật khẩu vào GitHub):

```dotenv
KATO_MOD_ADMIN_ROLE_IDS=
KATO_MODERATOR_ROLE_IDS=
KATO_MOD_LOG_CHANNEL_ID=
```

Điền ID role, cách nhau bằng dấu phẩy. Có thể để trống lúc đầu:

- Chủ server, Discord Administrator và ID nằm trong `KATO_OWNER_IDS` được xem là
  Admin.
- Role ID trong `KATO_MODERATOR_ROLE_IDS` được dùng các lệnh moderation.
- Nếu chưa cấu hình role, bot dùng quyền Discord tương ứng của người gọi theo
  từng lệnh (ví dụ `ban_members` cho `/mod ban`, `manage_messages` cho
  `/mod purge`). Một quyền đơn lẻ không tự mở khóa tất cả lệnh.
- `KATO_MOD_LOG_CHANNEL_ID` là ID kênh log riêng tư. Để trống hoặc `0` thì case
  chỉ được lưu trong SQLite.

## Quyền cần cấp cho bot

Chỉ cấp quyền cần dùng:

- Ban Members, Kick Members, Moderate Members.
- Manage Messages và Read Message History.
- Manage Channels.
- View Channel, Send Messages và Embed Links trong kênh log.

Role bot phải cao hơn các role của thành viên mà bot cần xử lý. Hệ thống kiểm tra
quyền bot và thứ tự role trước khi thực hiện. Quyền người gọi cũng được kiểm tra
riêng theo từng thao tác. Lệnh `/mod unlock` chỉ khôi phục giá trị `send_messages`
đã lưu ở lần `/mod lock` gần nhất; nếu không có case khóa hợp lệ, bot sẽ từ chối
thay đổi quyền để tránh vô tình mở một kênh vốn bị hạn chế.

## Kiểm thử trước khi dùng thật

1. Kiểm tra `/mod warn` với tài khoản thử nghiệm.
2. Kiểm tra `/mod warnings`, `/mod logs` và `/mod case`.
3. Thử timeout ngắn với tài khoản thử nghiệm.
4. Kiểm tra purge/slowmode/lock trên một kênh thử nghiệm.
5. Chỉ thử ban/kick sau khi xác nhận role hierarchy và quyền bot.

Bản cập nhật không sửa logic tu luyện, kinh tế, vật phẩm hoặc dữ liệu nhân vật.
