from __future__ import annotations

from pathlib import Path

ROOT = Path.cwd()
PROJECT = ROOT / "kato-tutien"


def validate_project() -> None:
    """Check every expected source anchor before the first write."""
    checks = [
        ("config.py", 'ADMIN_PASSWORD = env("KATO_ADMIN_PASSWORD")', "MOD_ADMIN_ROLE_IDS"),
        ("game/database/schema.py", "SCHEMA_VERSION = 16", "SCHEMA_VERSION = 17"),
        ("game/database/schema.py", "CREATE TABLE IF NOT EXISTS schema_meta", "CREATE TABLE IF NOT EXISTS moderation_cases"),
        ("game/engine.py", "from game.security.admin_auth import AdminAuth", "from game.moderation.service import ModerationService"),
        ("game/engine.py", "self.audit = self._audit", "self.moderation = ModerationService(db)"),
        ("bot.py", "from ui.commands import CommandContext, COMMAND_LOOKUP, COMMAND_SPECS", "from ui.commands.moderation import register_moderation_commands"),
        ("bot.py", "ctx = CommandContext(engine=engine, command_specs=COMMAND_SPECS)", "register_moderation_commands(tree, engine.moderation)"),
        ("pyproject.toml", 'version = "3.7.4"', 'version = "3.8.0"'),
    ]
    problems: list[str] = []
    for relative_path, anchor, marker in checks:
        path = PROJECT / relative_path
        if not path.exists():
            problems.append(f"missing {relative_path}")
            continue
        content = path.read_text(encoding="utf-8")
        if marker not in content and anchor not in content:
            problems.append(f"source anchor mismatch in {relative_path}")

    for relative_path in ("game/database/migrations.py", ".env.example", "VERSION.txt", "CHANGELOG.md"):
        if not (PROJECT / relative_path).exists():
            problems.append(f"missing {relative_path}")

    migration_path = PROJECT / "game/database/migrations.py"
    if migration_path.exists():
        migration_text = migration_path.read_text(encoding="utf-8")
        if "def migrate_16_to_17(db)" not in migration_text and "\n\n_MIGRATIONS = {\n" not in migration_text:
            problems.append("migration anchor mismatch in game/database/migrations.py")
        if "16: migrate_16_to_17," not in migration_text and "    15: migrate_15_to_16,\n" not in migration_text:
            problems.append("migration registry anchor mismatch in game/database/migrations.py")

    version_path = PROJECT / "VERSION.txt"
    if version_path.exists() and version_path.read_text(encoding="utf-8").strip() not in {"3.7.4", "3.8.0"}:
        problems.append("VERSION.txt is not 3.7.4 or 3.8.0")

    if problems:
        raise SystemExit(
            "Preflight failed; no files were changed:\n- " + "\n- ".join(problems)
        )


def update_file(relative_path: str, old: str, new: str, marker: str) -> None:
    path = PROJECT / relative_path
    if not path.exists():
        raise FileNotFoundError(f"Missing expected project file: {path}")
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print(f"SKIP (already updated): {relative_path}")
        return
    if old not in text:
        raise RuntimeError(f"Expected anchor not found in {relative_path}; no change made to this file")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"UPDATED: {relative_path}")


def main() -> None:
    if not PROJECT.is_dir():
        raise SystemExit(
            "Run this script from the KTT102026 repository root (the folder containing kato-tutien/)."
        )
    validate_project()
    print("Preflight passed; applying update.")

    update_file(
        "config.py",
        'ADMIN_PASSWORD = env("KATO_ADMIN_PASSWORD")\n',
        '''ADMIN_PASSWORD = env("KATO_ADMIN_PASSWORD")
MOD_ADMIN_ROLE_IDS = {
    int(value.strip()) for value in env("KATO_MOD_ADMIN_ROLE_IDS").split(",")
    if value.strip().isdigit() and int(value.strip()) > 0
}
MODERATOR_ROLE_IDS = {
    int(value.strip()) for value in env("KATO_MODERATOR_ROLE_IDS").split(",")
    if value.strip().isdigit() and int(value.strip()) > 0
}
try:
    MOD_LOG_CHANNEL_ID = int(env("KATO_MOD_LOG_CHANNEL_ID", "0") or "0")
except ValueError:
    MOD_LOG_CHANNEL_ID = 0
''',
        "MOD_ADMIN_ROLE_IDS",
    )

    update_file(
        "game/database/schema.py",
        "SCHEMA_VERSION = 16\n",
        "SCHEMA_VERSION = 17\n",
        "SCHEMA_VERSION = 17",
    )
    update_file(
        "game/database/schema.py",
        """CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
""",
        """CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS moderation_cases (
    case_id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    target_type TEXT NOT NULL DEFAULT 'user',
    action TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL,
    expires_at INTEGER,
    details TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_moderation_cases_guild_case
    ON moderation_cases(guild_id, case_id DESC);
CREATE INDEX IF NOT EXISTS idx_moderation_cases_target_action
    ON moderation_cases(guild_id, target_id, action, case_id DESC);
""",
        "CREATE TABLE IF NOT EXISTS moderation_cases",
    )

    migrations = PROJECT / "game/database/migrations.py"
    text = migrations.read_text(encoding="utf-8")
    if "def migrate_16_to_17(db)" not in text:
        anchor = "\n\n_MIGRATIONS = {\n"
        insert = '''

def migrate_16_to_17(db) -> None:
    # Manual Discord moderation history is isolated from in-game admin_audit.
    db.execute("""CREATE TABLE IF NOT EXISTS moderation_cases (
        case_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        moderator_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        target_type TEXT NOT NULL DEFAULT 'user',
        action TEXT NOT NULL,
        reason TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL,
        expires_at INTEGER,
        details TEXT NOT NULL DEFAULT ''
    )""")
    db.execute("""CREATE INDEX IF NOT EXISTS idx_moderation_cases_guild_case
        ON moderation_cases(guild_id, case_id DESC)""")
    db.execute("""CREATE INDEX IF NOT EXISTS idx_moderation_cases_target_action
        ON moderation_cases(guild_id, target_id, action, case_id DESC)""")
    _set_version(db, 17)
'''
        if anchor not in text:
            raise RuntimeError("Could not locate _MIGRATIONS anchor; migrations.py was not changed")
        text = text.replace(anchor, insert + anchor, 1)
    if "16: migrate_16_to_17," not in text:
        anchor = "    15: migrate_15_to_16,\n"
        if anchor not in text:
            raise RuntimeError("Could not locate schema 16 migration entry; migrations.py was not changed")
        text = text.replace(anchor, anchor + "    16: migrate_16_to_17,\n", 1)
    original_migrations = migrations.read_text(encoding="utf-8")
    if text != original_migrations:
        migrations.write_text(text, encoding="utf-8")
        print("UPDATED: game/database/migrations.py")
    else:
        print("SKIP (already updated): game/database/migrations.py")

    update_file(
        "game/engine.py",
        "from game.security.admin_auth import AdminAuth\n",
        "from game.security.admin_auth import AdminAuth\nfrom game.moderation.service import ModerationService\n",
        "from game.moderation.service import ModerationService",
    )
    update_file(
        "game/engine.py",
        "        self.audit = self._audit\n",
        "        self.audit = self._audit\n        self.moderation = ModerationService(db)\n",
        "self.moderation = ModerationService(db)",
    )
    update_file(
        "bot.py",
        "from ui.commands import CommandContext, COMMAND_LOOKUP, COMMAND_SPECS\n",
        "from ui.commands import CommandContext, COMMAND_LOOKUP, COMMAND_SPECS\nfrom ui.commands.moderation import register_moderation_commands\n",
        "from ui.commands.moderation import register_moderation_commands",
    )
    update_file(
        "bot.py",
        "ctx = CommandContext(engine=engine, command_specs=COMMAND_SPECS)\n",
        "ctx = CommandContext(engine=engine, command_specs=COMMAND_SPECS)\nregister_moderation_commands(tree, engine.moderation)\n",
        "register_moderation_commands(tree, engine.moderation)",
    )

    env_file = PROJECT / ".env.example"
    env_text = env_file.read_text(encoding="utf-8")
    if "KATO_MOD_ADMIN_ROLE_IDS=" not in env_text:
        env_text += "\n# Discord server moderation: comma-separated role IDs.\nKATO_MOD_ADMIN_ROLE_IDS=\nKATO_MODERATOR_ROLE_IDS=\n# Optional private text-channel ID for moderation case logs.\nKATO_MOD_LOG_CHANNEL_ID=\n"
        env_file.write_text(env_text, encoding="utf-8")
        print("UPDATED: .env.example")
    else:
        print("SKIP (already updated): .env.example")

    update_file(
        "pyproject.toml",
        'version = "3.7.4"',
        'version = "3.8.0"',
        'version = "3.8.0"',
    )

    version_file = PROJECT / "VERSION.txt"
    version_text = version_file.read_text(encoding="utf-8").strip()
    if version_text == "3.7.4":
        version_file.write_text("3.8.0\n", encoding="utf-8")
        print("UPDATED: VERSION.txt")
    elif version_text == "3.8.0":
        print("SKIP (already updated): VERSION.txt")
    else:
        raise RuntimeError(f"Unexpected VERSION.txt value {version_text!r}; expected 3.7.4")

    changelog = PROJECT / "CHANGELOG.md"
    changelog_text = changelog.read_text(encoding="utf-8")
    if "## v3.8.0 — Quản trị máy chủ Discord thủ công" not in changelog_text:
        note = '''## v3.8.0 — Quản trị máy chủ Discord thủ công

- Tích hợp nhóm Slash Commands `/mod` trên `discord.Client` + `app_commands.CommandTree` hiện tại.
- Bổ sung ban/unban, kick, timeout/untimeout, warn/xem cảnh cáo, purge, slowmode, lock/unlock và tra cứu case.
- Phân quyền qua Discord Owner/Admin, role ID cấu hình hoặc quyền quản trị Discord tương ứng; kiểm tra role hierarchy và quyền của bot trước khi xử lý.
- Tách lịch sử moderation khỏi `admin_audit` của gameplay bằng bảng `moderation_cases` và migration schema 16 → 17.
- Hỗ trợ kênh log tùy chọn qua `KATO_MOD_LOG_CHANNEL_ID`; không bật tự động quét link hoặc tự động xử phạt.
- Không thay đổi dữ liệu nhân vật, gameplay hoặc logic kinh tế.

'''
        changelog.write_text(note + changelog_text, encoding="utf-8")
        print("UPDATED: CHANGELOG.md")
    else:
        print("SKIP (already updated): CHANGELOG.md")

    print("\nUpdate applied. Review `git diff`, run tests, then commit/push when ready.")


if __name__ == "__main__":
    main()
