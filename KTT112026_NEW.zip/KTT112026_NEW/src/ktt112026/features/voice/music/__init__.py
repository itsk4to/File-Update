"""Per-guild music playback."""
