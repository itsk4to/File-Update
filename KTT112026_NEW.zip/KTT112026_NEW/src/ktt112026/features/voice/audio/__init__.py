"""Shared audio runtime helpers."""
