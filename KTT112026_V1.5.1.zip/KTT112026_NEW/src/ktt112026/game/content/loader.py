"""Load game content from JSON data files."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

def _get_data_dir() -> Path:
    # Try multiple fallback paths to ensure data files are always found regardless of install method or cwd
    candidates = [
        Path(__file__).resolve().parent / "data",
        Path.cwd() / "src" / "ktt112026" / "game" / "content" / "data",
        Path("/app/src/ktt112026/game/content/data"),
        Path(__file__).resolve().parents[2] / "game" / "content" / "data",
    ]
    for d in candidates:
        if d.is_dir() and (d / "sects.json").is_file():
            return d
    # Fallback to default relative to __file__ even if not fully verified
    return Path(__file__).resolve().parent / "data"

DATA_DIR = _get_data_dir()


def _load(name: str) -> dict[str, Any]:
    path = DATA_DIR / name
    if not path.is_file():
        # Try finding anywhere in python path or working dir
        for p in [Path.cwd() / name, Path(__file__).resolve().parent / name, Path("/app/src/ktt112026/game/content/data") / name]:
            if p.is_file():
                path = p
                break
    with path.open(encoding="utf-8") as f:
        return json.load(f)


@lru_cache(maxsize=16)
def load_danduoc() -> list[dict[str, Any]]:
    return list(_load("danduoc.json")["items"])


@lru_cache(maxsize=16)
def load_linhthu() -> list[dict[str, Any]]:
    return list(_load("linhthu.json")["items"])


@lru_cache(maxsize=16)
def load_congphap() -> list[dict[str, Any]]:
    return list(_load("congphap.json")["items"])


@lru_cache(maxsize=16)
def load_vukhi() -> list[dict[str, Any]]:
    return list(_load("vukhi.json")["items"])


@lru_cache(maxsize=16)
def load_phapbao() -> list[dict[str, Any]]:
    return list(_load("phapbao.json")["items"])


@lru_cache(maxsize=16)
def load_zones() -> list[dict[str, Any]]:
    return list(_load("zones.json")["zones"])


@lru_cache(maxsize=16)
def load_herbs() -> list[dict[str, Any]]:
    return list(_load("herbs.json")["items"])


@lru_cache(maxsize=16)
def load_recipes() -> list[dict[str, Any]]:
    return list(_load("recipes.json")["recipes"])


def catalog_by_id() -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for kind, loader in (
        ("danduoc", load_danduoc),
        ("linhthu", load_linhthu),
        ("congphap", load_congphap),
        ("vukhi", load_vukhi),
        ("phapbao", load_phapbao),
        ("herb", load_herbs),
    ):
        for it in loader():
            row = dict(it)
            row.setdefault("kind", kind)
            out[row["id"]] = row
    return out


def shop_stats_line(item: dict[str, Any]) -> str:
    if item.get("desc"):
        return str(item["desc"])
    parts = []
    for k, v in (item.get("bonuses") or {}).items():
        parts.append(f"+{v} {k}")
    for k, v in (item.get("penalties") or {}).items():
        parts.append(f"{v} {k}")
    return ", ".join(parts) if parts else ""

def load_sects() -> list[dict]:
    return list(_load("sects.json")["sects"])
