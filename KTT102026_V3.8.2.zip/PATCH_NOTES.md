# Kato Tu Tiên — Patch (bugfix + Unicode emoji)

## Emoji
- Tắt custom Discord emoji mặc định (`KATO_CUSTOM_EMOJI=0`)
- `assets/emojis/server/emojis.json` để trống
- UI dùng Unicode: 💎 🧘 👹 ⚔️ 💊 🏯 ☯️ 🌩️ 🏆 …

## Bugfix (giữ từ patch trước)
- inventory atomic, market claim, BEGIN IMMEDIATE
- market price/qty cap, cultivate/daily/hunt transaction, HP clamp Cửu Lôi

## Apply
```bash
unzip -o kato-tutien-patch-unicode-emoji.zip -d /path/to/repo/
```
