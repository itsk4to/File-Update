JSON content for game. sects.json must be committed to GitHub for full NPC list.
If missing at runtime, loader embeds default 8 NPC sects.
